# -*- coding: utf-8 -*-
"""
Created on Wed Mar  5 00:06:01 2025

@author: fatihgogus
"""


# Libraries
import matplotlib.pyplot as plt
import pandas as pd


# Import Data
myData = pd.read_csv('DataWithOnlyRoomNumber.txt')
#pd.read_csv("RentData.csv")
print(myData)

roomNumber = myData[['roomNumber']]
print(roomNumber)

rent = myData[['rent']]
print(rent)

# To divide the data for training and testing
from sklearn.model_selection import train_test_split

xTrain, xTest, yTrain, yTest = train_test_split(roomNumber,rent,test_size=0.5, random_state=0)

from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(xTrain, yTrain)

yPrediction = regressor.predict(xTest)

plt.plot(xTrain, yTrain, 'o')
plt.plot(xTest, yPrediction)

plt.show()





