# -*- coding: utf-8 -*-
"""
Created on Wed Mar  5 00:53:38 2025

@author: fatihgogus
"""

# Libraries

import matplotlib.pyplot as plt
import pandas as pd


# Import Data
myData = pd.read_csv('AgeData.txt')
#pd.read_csv("RentData.csv")
print(myData)

age = myData[['age']]
print(age)

rent = myData[['rent']]
print(rent)

# To divide the data for training and testing
from sklearn.model_selection import train_test_split

xTrain, xTest, yTrain, yTest = train_test_split(age,rent,test_size=0.5, random_state=0)


from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(xTrain, yTrain)

yPrediction = regressor.predict(xTest)


plt.plot(xTrain, yTrain, 'o')
plt.plot(xTest, yPrediction)

plt.title("House Rent")
plt.xlabel("House Age ")
plt.ylabel("Price")

plt.show()
