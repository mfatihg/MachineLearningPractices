# -*- coding: utf-8 -*-
"""
Created on Wed Mar  5 00:06:01 2025

@author: fatihgogus
"""

# Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# Import Data
myData = pd.read_csv('RentDataWithMultipleVariables.txt')
#pd.read_csv("RentData.csv")
print(myData)

roomNumber = myData.iloc[:,0].values
print(roomNumber)

houseAge = myData.iloc[:,1].values
print(houseAge)

price = myData.iloc[:,2].values
print(price)

# Convert numpy arrays into data frames
result1 = pd.DataFrame(data=roomNumber, index = range(len(myData)), columns = ['roomNumber'])
print(result1)

result2 = pd.DataFrame(data=houseAge, index = range(len(myData)), columns = ['age'])
print(result2)

result3 = pd.DataFrame(data = price, index = range(len(myData)), columns = ['rent'])
print(result3)

# Combine data frames
s = pd.concat([result1,result2], axis=1)
print(s)

s2 = pd.concat([s,result3], axis=1)
print(s2)

# To divide the data for training and testing
from sklearn.model_selection import train_test_split

xTrain, xTest, yTrain, yTest = train_test_split(s,result3,test_size=0.5, random_state=0)

from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(xTrain, yTrain)

yPrediction = regressor.predict(xTest)

xTrain = xTrain.sort_index()
yTrain = yTrain.sort_index()

plt.figure(figsize=(8,6))

plt.scatter(yTest, yPrediction, color='blue', alpha=0.5, label="Real")
plt.plot([yTest.min(), yTest.max()], [yTest.min(), yTest.max()], color="red", linestyle="--", label="Prediction Line")

plt.xlabel("Actual Price")
plt.ylabel("Predicted Price")
plt.legend()
plt.title("Real vs Prediction (Model Performance)")
plt.show()

import statsmodels.api as sm

X = np.append(arr = np.ones((len(myData),1)).astype(int), values=s, axis=1)

X_l = s.iloc[:,[0,1]].values
X_l = np.array(X_l,dtype=float)
model = sm.OLS(price,X_l).fit()
print(model.summary())







