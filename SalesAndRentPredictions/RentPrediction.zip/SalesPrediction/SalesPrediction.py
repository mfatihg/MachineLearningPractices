# -*- coding: utf-8 -*-
"""
Created on Wed Mar  5 00:06:01 2025

@author: fatihgogus
"""


# Libraries
import matplotlib.pyplot as plt
import pandas as pd

# Import Data 
veriler = pd.read_csv('sales.txt')
#pd.read_csv("veriler.csv")

# Data Preprocessing
months = veriler[['months']]
print(months)

sales = veriler[['sales']]
print(sales)

# Divide data for training and testing
from sklearn.model_selection import train_test_split

x_train, x_test,y_train,y_test = train_test_split(months,sales,test_size=0.33, random_state=0)


# Build The Model
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(x_train,y_train)

prediction = lr.predict(x_test)

x_train = x_train.sort_index()
y_train = y_train.sort_index()

x_test = x_train.sort_index()
y_test = y_train.sort_index()

plt.plot(x_train,y_train, 'o')
plt.plot(x_test,lr.predict(x_test))

plt.title("Sales to Months")
plt.xlabel("Months")
plt.ylabel("Sales")

plt.show()













    
    

